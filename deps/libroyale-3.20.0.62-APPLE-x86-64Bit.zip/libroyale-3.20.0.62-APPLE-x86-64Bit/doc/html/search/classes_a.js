var searchData=
[
  ['pair',['Pair',['../classroyale_1_1_pair.html',1,'royale']]],
  ['pair_3c_20float_2c_20float_20_3e',['Pair&lt; float, float &gt;',['../classroyale_1_1_pair.html',1,'royale']]]
];
