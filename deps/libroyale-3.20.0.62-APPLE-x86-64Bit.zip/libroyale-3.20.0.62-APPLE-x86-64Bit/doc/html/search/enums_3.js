var searchData=
[
  ['royale_5fcallback_5fdata',['royale_callback_data',['../group__royale_c_a_p_i.html#ga990e3f18d9b085558f11859e12c2244f',1,'ExtendedDataCAPI.h']]],
  ['royale_5fcamera_5faccess_5flevel',['royale_camera_access_level',['../group__royale_c_a_p_i.html#ga313c3f1b5b5460f933915a6e22ab2895',1,'CameraDeviceCAPI.h']]],
  ['royale_5fcamera_5fstatus',['royale_camera_status',['../group__royale_c_a_p_i.html#gaabcc5ca64cfb3f257f7ab6444dd33125',1,'StatusCAPI.h']]],
  ['royale_5fevent_5fseverity',['royale_event_severity',['../group__royale_c_a_p_i.html#ga8fbc64a0e42e5bae8d1939a70c86aae9',1,'EventCAPI.h']]],
  ['royale_5fevent_5ftype',['royale_event_type',['../group__royale_c_a_p_i.html#ga605b6167cc48e44c33f6c801ca6be435',1,'EventCAPI.h']]],
  ['royale_5fexposure_5fmode',['royale_exposure_mode',['../group__royale_c_a_p_i.html#ga3ba861577a5ffd266c64657d2be4208e',1,'ExposureModeCAPI.h']]],
  ['royale_5fprocessing_5fflag',['royale_processing_flag',['../group__royale_c_a_p_i.html#ga300326ddeca40e9f02877bb758194687',1,'ProcessingParametersCAPI.h']]],
  ['royale_5ftrigger_5fmode',['royale_trigger_mode',['../group__royale_c_a_p_i.html#ga4ff43496e111ad61c94ce3207a5b785a',1,'TriggerModeCAPI.h']]],
  ['royale_5fvariant_5ftype',['royale_variant_type',['../group__royale_c_a_p_i.html#ga43a4b6ffa3101dcf641f489b2463b0b2',1,'VariantCAPI.h']]]
];
