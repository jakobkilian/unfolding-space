var searchData=
[
  ['varianttype',['VariantType',['../class_royale_dot_net_1_1_variant.html#af9f10189cc9349f098c8ef5eb44d6272',1,'RoyaleDotNet.Variant.VariantType()'],['../namespaceroyale.html#af729d5b431bf0b5a41c66513d30838d8',1,'royale::VariantType()']]]
];
