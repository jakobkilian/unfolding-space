var searchData=
[
  ['forward_5fiterator_5ftag',['forward_iterator_tag',['../structroyale_1_1iterator_1_1forward__iterator__tag.html',1,'royale::iterator']]]
];
