var searchData=
[
  ['wrong_5fdata_5fformat_5ffound',['WRONG_DATA_FORMAT_FOUND',['../namespace_royale_dot_net.html#a7c470186ff8f9b10c7383e4fde017288aacc2fff8761448264a43d967f18b0c06',1,'RoyaleDotNet.WRONG_DATA_FORMAT_FOUND()'],['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054aacc2fff8761448264a43d967f18b0c06',1,'royale::WRONG_DATA_FORMAT_FOUND()']]]
];
