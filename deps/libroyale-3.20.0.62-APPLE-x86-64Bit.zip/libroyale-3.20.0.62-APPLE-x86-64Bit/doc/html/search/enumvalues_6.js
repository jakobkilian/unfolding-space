var searchData=
[
  ['globalbinning_5fint',['GlobalBinning_Int',['../namespace_royale_dot_net.html#ab3fdff3ffcdd389ecf09923b128459c8aa3a03ccf5b5263863dd1624a91f70acb',1,'RoyaleDotNet.GlobalBinning_Int()'],['../namespaceroyale.html#a7e10115488b46d46ac7703679b4e02c8aa3a03ccf5b5263863dd1624a91f70acb',1,'royale::GlobalBinning_Int()']]]
];
