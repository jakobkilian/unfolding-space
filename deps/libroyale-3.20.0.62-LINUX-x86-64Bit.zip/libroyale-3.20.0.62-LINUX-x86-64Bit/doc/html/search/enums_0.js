var searchData=
[
  ['callbackdata',['CallbackData',['../namespace_royale_dot_net.html#aefa4a38a0bc09826af9e30817a842120',1,'RoyaleDotNet.CallbackData()'],['../namespaceroyale.html#a81008e7d512d2a5b1e90a40a50070344',1,'royale::CallbackData()']]],
  ['cameraaccesslevel',['CameraAccessLevel',['../class_royale_dot_net_1_1_camera_device.html#af1d22f05ffc17482577a362b63bcc951',1,'RoyaleDotNet.CameraDevice.CameraAccessLevel()'],['../namespaceroyale.html#ae779af860153ff8fd846fdcfb7b381e8',1,'royale::CameraAccessLevel()']]],
  ['camerastatus',['CameraStatus',['../namespace_royale_dot_net.html#a7c470186ff8f9b10c7383e4fde017288',1,'RoyaleDotNet.CameraStatus()'],['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054',1,'royale::CameraStatus()']]]
];
