var searchData=
[
  ['no_5fcalibration_5fdata',['NO_CALIBRATION_DATA',['../namespace_royale_dot_net.html#a7c470186ff8f9b10c7383e4fde017288a2de6fbbba417e4d4f8b0f99c852f28f5',1,'RoyaleDotNet.NO_CALIBRATION_DATA()'],['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054a2de6fbbba417e4d4f8b0f99c852f28f5',1,'royale::NO_CALIBRATION_DATA()']]],
  ['no_5fuse_5fcases',['NO_USE_CASES',['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054a0531161a19f49d211de84106a0241b12',1,'royale']]],
  ['no_5fuse_5fcases_5ffor_5flevel',['NO_USE_CASES_FOR_LEVEL',['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054a5c0cef8053349d44bfb6c68383d6d69c',1,'royale']]],
  ['noisethreshold_5ffloat',['NoiseThreshold_Float',['../namespace_royale_dot_net.html#ab3fdff3ffcdd389ecf09923b128459c8acc5d0c0a13c203aa4f515d2a8f690b9a',1,'RoyaleDotNet.NoiseThreshold_Float()'],['../namespaceroyale.html#a7e10115488b46d46ac7703679b4e02c8acc5d0c0a13c203aa4f515d2a8f690b9a',1,'royale::NoiseThreshold_Float()']]],
  ['none',['None',['../namespace_royale_dot_net.html#aefa4a38a0bc09826af9e30817a842120a6adf97f83acf6453d4a6a4b1070f3754',1,'RoyaleDotNet.None()'],['../namespaceroyale.html#a81008e7d512d2a5b1e90a40a50070344a6adf97f83acf6453d4a6a4b1070f3754',1,'royale::None()']]],
  ['not_5fimplemented',['NOT_IMPLEMENTED',['../namespace_royale_dot_net.html#a7c470186ff8f9b10c7383e4fde017288a3e860a081575fc82cc7b6ed2ca602947',1,'RoyaleDotNet.NOT_IMPLEMENTED()'],['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054a3e860a081575fc82cc7b6ed2ca602947',1,'royale::NOT_IMPLEMENTED()']]],
  ['num_5fflags',['NUM_FLAGS',['../namespaceroyale.html#a7e10115488b46d46ac7703679b4e02c8a373be204df706aa83739caa20dca1cda',1,'royale']]]
];
