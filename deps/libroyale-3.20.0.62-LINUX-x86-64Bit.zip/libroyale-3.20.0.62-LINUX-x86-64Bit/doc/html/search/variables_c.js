var searchData=
[
  ['raw_5fdata',['raw_data',['../structroyale__extended__data.html#a4a3ecf492bb692a5e47b2f0f9062d1be',1,'royale_extended_data::raw_data()'],['../structroyale__raw__data.html#a622ee25acf01a968ed76e9048923dd94',1,'royale_raw_data::raw_data()']]],
  ['rawdata',['rawData',['../struct_royale_dot_net_1_1_raw_data.html#a2abeccd07a81be29e17aa42865f4fa14',1,'RoyaleDotNet.RawData.rawData()'],['../structroyale_1_1_raw_data.html#a99f21af084df6c14f27513b164d987c0',1,'royale::RawData::rawData()']]],
  ['rawframecount',['rawFrameCount',['../structroyale_1_1_raw_data.html#a7625a146fb4ded5b74e0c00d8fb78839',1,'royale::RawData']]],
  ['royale_5fcam_5fmanager_5fhnd',['royale_cam_manager_hnd',['../group__royale_c_a_p_i.html#gac6e46205b3c174d256c01ace156d4125',1,'CameraManagerCAPI.h']]],
  ['royale_5fcamera_5fhandle',['royale_camera_handle',['../group__royale_c_a_p_i.html#ga756f22190e8e503cbd8ec53fbab0928b',1,'CameraDeviceCAPI.h']]],
  ['royale_5fdepth_5fdata_5fcallback',['ROYALE_DEPTH_DATA_CALLBACK',['../group__royale_c_a_p_i.html#ga39a7e76114a6466b47daaa521b3428d6',1,'DepthDataCAPI.h']]],
  ['royale_5fdepth_5fimage_5fcallback',['ROYALE_DEPTH_IMAGE_CALLBACK',['../group__royale_c_a_p_i.html#ga30e11c98edbb037d223ebad3aac64905',1,'DepthImageCAPI.h']]],
  ['royale_5fevent_5fcallback',['ROYALE_EVENT_CALLBACK',['../group__royale_c_a_p_i.html#gae2b515745513e9fe30bbc0887e77b2ea',1,'EventCAPI.h']]],
  ['royale_5fexposure_5fcallback_5fv210',['ROYALE_EXPOSURE_CALLBACK_v210',['../group__royale_c_a_p_i.html#ga81e24acd4a1924c38d21bcde80665cf3',1,'ExposureCAPI.h']]],
  ['royale_5fexposure_5fcallback_5fv300',['ROYALE_EXPOSURE_CALLBACK_v300',['../group__royale_c_a_p_i.html#ga72222075fa7da565e6778fdfb7efff7e',1,'ExposureCAPI.h']]],
  ['royale_5fintermediate_5fdata_5fcallback',['ROYALE_INTERMEDIATE_DATA_CALLBACK',['../group__royale_c_a_p_i.html#ga0a5fab366f4b3ade1b832502352d15f8',1,'IntermediateDataCAPI.h']]],
  ['royale_5fir_5fimage_5fcallback',['ROYALE_IR_IMAGE_CALLBACK',['../group__royale_c_a_p_i.html#gaa0fde4bf4b8614677113c0f7fe034b55',1,'IRImageCAPI.h']]],
  ['royale_5fraw_5fdata_5fcallback',['ROYALE_RAW_DATA_CALLBACK',['../group__royale_c_a_p_i.html#ga418f4b8ac789091c0a84123d1e04be28',1,'RawDataCAPI.h']]],
  ['royale_5frecord_5fstop_5fcallback',['ROYALE_RECORD_STOP_CALLBACK',['../group__royale_c_a_p_i.html#ga6e3b74242c6335587dc4cb24678cbe38',1,'RecordCAPI.h']]],
  ['royale_5fspc_5fdata_5fcallback',['ROYALE_SPC_DATA_CALLBACK',['../group__royale_c_a_p_i.html#gafb60abdea3189299e2f206f39eba5479',1,'SparsePointCloudCAPI.h']]]
];
