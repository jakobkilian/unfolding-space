var searchData=
[
  ['size_5ftype',['size_type',['../classroyale_1_1basic_string.html#a114882b7ee678c295e29f66972950f4d',1,'royale::basicString::size_type()'],['../classroyale_1_1_vector.html#a94c5527991dba00b103732a1bb04b669',1,'royale::Vector::size_type()']]],
  ['streamid',['StreamId',['../namespaceroyale.html#acc5b9d945c66ef2cf06d26ff653e9051',1,'royale']]],
  ['string',['String',['../namespaceroyale.html#af4f27cdc52db54b2af329234f987d35c',1,'royale']]]
];
