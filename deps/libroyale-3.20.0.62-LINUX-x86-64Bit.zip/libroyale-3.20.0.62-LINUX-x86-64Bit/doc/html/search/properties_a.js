var searchData=
[
  ['rawdata',['RawData',['../class_royale_dot_net_1_1_extended_data.html#a36e52e67dda336e6e28a60bd9ca2a850',1,'RoyaleDotNet::ExtendedData']]]
];
