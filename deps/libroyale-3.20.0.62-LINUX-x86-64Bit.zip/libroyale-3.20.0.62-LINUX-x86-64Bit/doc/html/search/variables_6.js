var searchData=
[
  ['gray_5fvalue',['gray_value',['../structroyale__depth__point.html#a1c50cc4384668713eb538e2fa51e0e8f',1,'royale_depth_point']]],
  ['grayvalue',['grayValue',['../struct_royale_dot_net_1_1_depth_point.html#ad9b511d187f09a925d562239cce82dfd',1,'RoyaleDotNet.DepthPoint.grayValue()'],['../structroyale_1_1_depth_point.html#ac8aa1097581556ca29048a1dfd6c920c',1,'royale::DepthPoint::grayValue()']]]
];
