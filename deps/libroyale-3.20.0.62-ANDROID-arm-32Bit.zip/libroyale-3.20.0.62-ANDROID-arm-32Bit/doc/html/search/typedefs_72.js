var searchData=
[
  ['reference',['reference',['../classroyale_1_1iterator_1_1royale__iterator__skeleton.html#a87661b2aa43bc0f2eeb088aa4adbc2f4',1,'royale::iterator::royale_iterator_skeleton::reference()'],['../classroyale_1_1basic_string.html#a5d539cda1422c12a7dfa80f82020dfb8',1,'royale::basicString::reference()'],['../classroyale_1_1_vector.html#a0ac3aef4b8475c957a9adcd934f306be',1,'royale::Vector::reference()']]],
  ['reverse_5fiterator',['reverse_iterator',['../classroyale_1_1basic_string.html#ae98bf79c04dc2a790a5e36373e045121',1,'royale::basicString::reverse_iterator()'],['../classroyale_1_1_vector.html#a345b6aabe433b423c419b87699e38554',1,'royale::Vector::reverse_iterator()']]],
  ['royale_5fcallback_5fdata',['royale_callback_data',['../group__royale_c_a_p_i.html#ga2507701589c638913bd53cf514ea9457',1,'ExtendedDataCAPI.h']]],
  ['royale_5fcamera_5faccess_5flevel',['royale_camera_access_level',['../group__royale_c_a_p_i.html#gaf2353cc8e8ee8da1a3386e8722ecd858',1,'CameraDeviceCAPI.h']]],
  ['royale_5fcamera_5fstatus',['royale_camera_status',['../group__royale_c_a_p_i.html#gaee98f5e3f37d58512663e79c18cf55d7',1,'StatusCAPI.h']]],
  ['royale_5fevent_5fseverity',['royale_event_severity',['../group__royale_c_a_p_i.html#ga8ae4106b4c1f0b43b69cb2baf6a0fcdf',1,'EventCAPI.h']]],
  ['royale_5fevent_5ftype',['royale_event_type',['../group__royale_c_a_p_i.html#ga1273de538eafc5dbb5dfee3e45b301f3',1,'EventCAPI.h']]],
  ['royale_5fexposure_5flimits',['royale_exposure_limits',['../group__royale_c_a_p_i.html#ga08266c1bdab463908cc3ef17e091e2eb',1,'CameraDeviceCAPI.h']]],
  ['royale_5fexposure_5fmode',['royale_exposure_mode',['../group__royale_c_a_p_i.html#gaae4ebf6adb78fc488821d86d39bd207c',1,'ExposureModeCAPI.h']]],
  ['royale_5fextended_5fdata_5fcallback',['ROYALE_EXTENDED_DATA_CALLBACK',['../group__royale_c_a_p_i.html#ga68d5fac3cf9816dd3accbd20aada0e82',1,'ExtendedDataCAPI.h']]],
  ['royale_5fprocessing_5fflag',['royale_processing_flag',['../group__royale_c_a_p_i.html#ga5775e778665b07181d44f6c905106271',1,'ProcessingParametersCAPI.h']]],
  ['royale_5fstream_5fid',['royale_stream_id',['../group__royale_c_a_p_i.html#gafa71a01dfb94643e1f06b44b675bad79',1,'DataStructuresCAPI.h']]],
  ['royale_5ftrigger_5fmode',['royale_trigger_mode',['../group__royale_c_a_p_i.html#ga3ad7806578ae4e530ae110f8ae60ba77',1,'TriggerModeCAPI.h']]],
  ['royale_5fvariant',['royale_variant',['../group__royale_c_a_p_i.html#ga51d98667e33f8f3c78559ed60d31da72',1,'VariantCAPI.h']]],
  ['royale_5fvariant_5ftype',['royale_variant_type',['../group__royale_c_a_p_i.html#ga8823a3fba64e30ddcc81d48e03a9b34f',1,'VariantCAPI.h']]]
];
