var searchData=
[
  ['wstring',['WString',['../namespaceroyale.html#a173d0ec8c223f2afbc98fcc1ccb2e057',1,'royale']]]
];
