var searchData=
[
  ['out_5fof_5fbounds',['OUT_OF_BOUNDS',['../namespace_royale_dot_net.html#a7c470186ff8f9b10c7383e4fde017288a71e5e8b8caeedea08ea1f0e75143e047',1,'RoyaleDotNet.OUT_OF_BOUNDS()'],['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054a71e5e8b8caeedea08ea1f0e75143e047',1,'royale::OUT_OF_BOUNDS()']]]
];
