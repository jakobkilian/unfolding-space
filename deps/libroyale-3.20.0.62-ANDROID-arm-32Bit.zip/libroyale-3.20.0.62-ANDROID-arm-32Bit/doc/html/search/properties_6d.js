var searchData=
[
  ['modulationfrequency',['ModulationFrequency',['../class_royale_dot_net_1_1_modulation_sequence.html#ad6f1d64025efcdb844c80a47ccac9f4c',1,'RoyaleDotNet::ModulationSequence']]]
];
