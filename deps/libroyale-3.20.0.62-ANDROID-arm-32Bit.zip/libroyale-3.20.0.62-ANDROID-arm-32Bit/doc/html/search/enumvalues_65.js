var searchData=
[
  ['exposure_5fmode_5finvalid',['EXPOSURE_MODE_INVALID',['../namespace_royale_dot_net.html#a7c470186ff8f9b10c7383e4fde017288a567cec230bcf80e7e62894675c4631c3',1,'RoyaleDotNet.EXPOSURE_MODE_INVALID()'],['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054a567cec230bcf80e7e62894675c4631c3',1,'royale::EXPOSURE_MODE_INVALID()']]],
  ['exposure_5ftime_5fnot_5fsupported',['EXPOSURE_TIME_NOT_SUPPORTED',['../namespace_royale_dot_net.html#a7c470186ff8f9b10c7383e4fde017288a1b139ce45c714e8e6f83602a2806b59b',1,'RoyaleDotNet.EXPOSURE_TIME_NOT_SUPPORTED()'],['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054a1b139ce45c714e8e6f83602a2806b59b',1,'royale::EXPOSURE_TIME_NOT_SUPPORTED()']]]
];
