var searchData=
[
  ['timeout',['TIMEOUT',['../namespace_royale_dot_net.html#a7c470186ff8f9b10c7383e4fde017288a070a0fb40f6c308ab544b227660aadff',1,'RoyaleDotNet.TIMEOUT()'],['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054a070a0fb40f6c308ab544b227660aadff',1,'royale::TIMEOUT()']]]
];
