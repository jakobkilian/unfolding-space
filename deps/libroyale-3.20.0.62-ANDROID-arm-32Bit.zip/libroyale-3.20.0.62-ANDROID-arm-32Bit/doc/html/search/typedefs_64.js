var searchData=
[
  ['difference_5ftype',['difference_type',['../classroyale_1_1iterator_1_1royale__iterator__skeleton.html#a2758719859a8c4d4a9d6aee623302d3f',1,'royale::iterator::royale_iterator_skeleton::difference_type()'],['../classroyale_1_1basic_string.html#ac9e483d21c3e48468b5cf686a15be1ad',1,'royale::basicString::difference_type()']]]
];
