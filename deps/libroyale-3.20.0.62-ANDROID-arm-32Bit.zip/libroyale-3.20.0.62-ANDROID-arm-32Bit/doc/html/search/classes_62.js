var searchData=
[
  ['basicstring',['basicString',['../classroyale_1_1basic_string.html',1,'royale']]],
  ['bidirection_5fiterator_5ftag',['bidirection_iterator_tag',['../structroyale_1_1iterator_1_1bidirection__iterator__tag.html',1,'royale::iterator']]]
];
