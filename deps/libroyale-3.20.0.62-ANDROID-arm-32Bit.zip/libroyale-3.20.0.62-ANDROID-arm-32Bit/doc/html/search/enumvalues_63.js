var searchData=
[
  ['calibration_5fdata_5ferror',['CALIBRATION_DATA_ERROR',['../namespace_royale_dot_net.html#a7c470186ff8f9b10c7383e4fde017288ad2afd1660a6f653dfc0ffd6ae6a9f6fd',1,'RoyaleDotNet.CALIBRATION_DATA_ERROR()'],['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054ad2afd1660a6f653dfc0ffd6ae6a9f6fd',1,'royale::CALIBRATION_DATA_ERROR()']]],
  ['consistencytolerance_5ffloat',['ConsistencyTolerance_Float',['../namespace_royale_dot_net.html#ab3fdff3ffcdd389ecf09923b128459c8a383202a0a1719fd4a5dcf29f2dd30938',1,'RoyaleDotNet.ConsistencyTolerance_Float()'],['../namespaceroyale.html#a7e10115488b46d46ac7703679b4e02c8a383202a0a1719fd4a5dcf29f2dd30938',1,'royale::ConsistencyTolerance_Float()']]],
  ['could_5fnot_5fopen',['COULD_NOT_OPEN',['../namespace_royale_dot_net.html#a7c470186ff8f9b10c7383e4fde017288af2289cc22d77b1f6efa13a077f96967a',1,'RoyaleDotNet.COULD_NOT_OPEN()'],['../namespaceroyale.html#a895d6f2339238d7f35b996906bd7d054af2289cc22d77b1f6efa13a077f96967a',1,'royale::COULD_NOT_OPEN()']]]
];
