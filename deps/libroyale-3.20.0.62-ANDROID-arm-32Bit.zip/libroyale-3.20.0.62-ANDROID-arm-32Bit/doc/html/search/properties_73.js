var searchData=
[
  ['severity',['Severity',['../class_royale_dot_net_1_1_event.html#a8eb79c79877bbf4601a7dc00f0cbfae4',1,'RoyaleDotNet::Event']]]
];
