var searchData=
[
  ['royale',['Royale',['../group__royale.html',1,'']]],
  ['royalecapi',['RoyaleCAPI',['../group__royale_c_a_p_i.html',1,'']]],
  ['royaledotnet',['RoyaleDotNet',['../group___royale_dot_net.html',1,'']]]
];
