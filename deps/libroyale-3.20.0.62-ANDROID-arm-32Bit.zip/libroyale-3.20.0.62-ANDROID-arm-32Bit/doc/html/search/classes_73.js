var searchData=
[
  ['sparsepointcloud',['SparsePointCloud',['../structroyale_1_1_sparse_point_cloud.html',1,'royale']]],
  ['sparsepointcloud',['SparsePointCloud',['../struct_royale_dot_net_1_1_sparse_point_cloud.html',1,'RoyaleDotNet']]],
  ['status',['Status',['../class_royale_dot_net_1_1_status.html',1,'RoyaleDotNet']]],
  ['streamid',['StreamId',['../class_royale_dot_net_1_1_stream_id.html',1,'RoyaleDotNet']]]
];
