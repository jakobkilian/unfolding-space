var searchData=
[
  ['data',['data',['../structroyale__ir__image.html#a823e8efce21c5172a6f8fc7c966841f3',1,'royale_ir_image::data()'],['../structroyale__variant.html#a7e311190c22d8c0080edcfdca64b789c',1,'royale_variant::data()'],['../struct_royale_dot_net_1_1_i_r_image.html#ab113b8b600c00d0c53ac44a14bcc669f',1,'RoyaleDotNet.IRImage.data()'],['../structroyale_1_1_i_r_image.html#a9ff48327ec18ea7bab291f1b5eb9066e',1,'royale::IRImage::data()']]],
  ['depth_5fconfidence',['depth_confidence',['../structroyale__depth__point.html#a6d62ee28291c88e9162923b1fbd45231',1,'royale_depth_point']]],
  ['depth_5fdata',['depth_data',['../structroyale__extended__data.html#ada15e89acf537f77b832a14772feb1ba',1,'royale_extended_data']]],
  ['depthconfidence',['depthConfidence',['../struct_royale_dot_net_1_1_depth_point.html#a23765eb79c409319d78170fde045f704',1,'RoyaleDotNet.DepthPoint.depthConfidence()'],['../structroyale_1_1_depth_point.html#a9daa5050bea347d0e3d647edb2ba81b1',1,'royale::DepthPoint::depthConfidence()']]],
  ['description',['description',['../structroyale__event.html#ab37a5c36d6e7c17b9b287b8725bd86c0',1,'royale_event']]],
  ['distance',['distance',['../structroyale__intermediate__point.html#a38021cc7939cc6a483b617fbfd296b31',1,'royale_intermediate_point::distance()'],['../struct_royale_dot_net_1_1_intermediate_point.html#a4880f553a92ad8cde6a2b86a4498cb6c',1,'RoyaleDotNet.IntermediatePoint.distance()'],['../structroyale_1_1_intermediate_point.html#ac1c04581e8c2e193f0fec2c3308bfeb0',1,'royale::IntermediatePoint::distance()']]],
  ['distortionradial',['distortionRadial',['../structroyale__lens__parameters.html#a9063e4695bd4ba1f02667a5a380e7800',1,'royale_lens_parameters::distortionRadial()'],['../structroyale_1_1_lens_parameters.html#a636e9f4f9af64d47f8e2167231918f87',1,'royale::LensParameters::distortionRadial()']]],
  ['distortiontangential',['distortionTangential',['../structroyale__lens__parameters.html#a9e117dbf1d1f46544ce6b7f33c515ca5',1,'royale_lens_parameters::distortionTangential()'],['../structroyale_1_1_lens_parameters.html#a0daee245109829761267bf5e44af5393',1,'royale::LensParameters::distortionTangential()']]]
];
