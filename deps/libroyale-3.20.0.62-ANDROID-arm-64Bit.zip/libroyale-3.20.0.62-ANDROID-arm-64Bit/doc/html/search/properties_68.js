var searchData=
[
  ['hasdepthdata',['HasDepthData',['../class_royale_dot_net_1_1_extended_data.html#a84d615addf43f9fb10433b3edd5c9f62',1,'RoyaleDotNet::ExtendedData']]],
  ['hasintermediatedata',['HasIntermediateData',['../class_royale_dot_net_1_1_extended_data.html#aa6178fd2fc2d68a11937c4d3bad43dda',1,'RoyaleDotNet::ExtendedData']]],
  ['hasrawdata',['HasRawData',['../class_royale_dot_net_1_1_extended_data.html#af362ea47ea9b9b93b01a8ac4708e083a',1,'RoyaleDotNet::ExtendedData']]]
];
