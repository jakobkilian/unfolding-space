var searchData=
[
  ['b',['b',['../structroyale__variant.html#ac1c3f75bc9d5830c8567110ef81934f2',1,'royale_variant::b()'],['../classroyale_1_1_variant.html#a06abedf68a98b02aa5377850f3794804',1,'royale::Variant::b()']]]
];
