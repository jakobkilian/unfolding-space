var searchData=
[
  ['type',['Type',['../class_royale_dot_net_1_1_event.html#aa247a16c6a4ac9dd26a217e8f2c6cb3e',1,'RoyaleDotNet.Event.Type()'],['../class_royale_dot_net_1_1_variant.html#a5534d27dc25c291dc1cb61838e9d3370',1,'RoyaleDotNet.Variant.Type()']]]
];
