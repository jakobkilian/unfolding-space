var searchData=
[
  ['hasdepthdata',['hasDepthData',['../classroyale_1_1_i_extended_data.html#a1778a08d2d8111f0b0f7fef8fce2ffc8',1,'royale::IExtendedData']]],
  ['hasintermediatedata',['hasIntermediateData',['../classroyale_1_1_i_extended_data.html#a940bdadf181667a67fa79e3267347edb',1,'royale::IExtendedData']]],
  ['hasrawdata',['hasRawData',['../classroyale_1_1_i_extended_data.html#aab14458ab1f9ed69aa981de73e09361d',1,'royale::IExtendedData']]]
];
