var searchData=
[
  ['intermediatedata',['IntermediateData',['../class_royale_dot_net_1_1_extended_data.html#a84e992a27107d92ac945544b5e5ac51e',1,'RoyaleDotNet::ExtendedData']]]
];
