var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwxyz~",
  1: "abcdefilmoprsv",
  2: "r",
  3: "cdefilmprstv",
  4: "abcdefghilmnoprstuvw~",
  5: "abcdefghimnprstvwxyz",
  6: "acdhiprstvw",
  7: "cefprtv",
  8: "abcdefgilmnorstuw",
  9: "cdefhiklmprstu",
  10: "co",
  11: "r",
  12: "r",
  13: "di"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "properties",
  10: "related",
  11: "defines",
  12: "groups",
  13: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Properties",
  10: "Friends",
  11: "Macros",
  12: "Modules",
  13: "Pages"
};

