var searchData=
[
  ['hasdepthdata',['hasDepthData',['../a00039.html#a1778a08d2d8111f0b0f7fef8fce2ffc8',1,'royale::IExtendedData']]],
  ['hasintermediatedata',['hasIntermediateData',['../a00039.html#a940bdadf181667a67fa79e3267347edb',1,'royale::IExtendedData']]],
  ['hasrawdata',['hasRawData',['../a00039.html#aab14458ab1f9ed69aa981de73e09361d',1,'royale::IExtendedData']]]
];
