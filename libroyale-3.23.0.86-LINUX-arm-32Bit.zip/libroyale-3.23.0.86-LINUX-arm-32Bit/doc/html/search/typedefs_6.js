var searchData=
[
  ['reference',['reference',['../a00087.html#a87661b2aa43bc0f2eeb088aa4adbc2f4',1,'royale::iterator::royale_iterator_skeleton::reference()'],['../a00010.html#a5d539cda1422c12a7dfa80f82020dfb8',1,'royale::basicString::reference()'],['../a00110.html#a0ac3aef4b8475c957a9adcd934f306be',1,'royale::Vector::reference()']]],
  ['reverse_5fiterator',['reverse_iterator',['../a00010.html#ae98bf79c04dc2a790a5e36373e045121',1,'royale::basicString::reverse_iterator()'],['../a00110.html#a345b6aabe433b423c419b87699e38554',1,'royale::Vector::reverse_iterator()']]],
  ['royale_5fcallback_5fdata',['royale_callback_data',['../a00218.html#ga2507701589c638913bd53cf514ea9457',1,'ExtendedDataCAPI.h']]],
  ['royale_5fcamera_5faccess_5flevel',['royale_camera_access_level',['../a00218.html#gaf2353cc8e8ee8da1a3386e8722ecd858',1,'CameraDeviceCAPI.h']]],
  ['royale_5fcamera_5fstatus',['royale_camera_status',['../a00218.html#gaee98f5e3f37d58512663e79c18cf55d7',1,'StatusCAPI.h']]],
  ['royale_5fevent_5fseverity',['royale_event_severity',['../a00218.html#ga8ae4106b4c1f0b43b69cb2baf6a0fcdf',1,'EventCAPI.h']]],
  ['royale_5fevent_5ftype',['royale_event_type',['../a00218.html#ga1273de538eafc5dbb5dfee3e45b301f3',1,'EventCAPI.h']]],
  ['royale_5fexposure_5flimits',['royale_exposure_limits',['../a00218.html#ga08266c1bdab463908cc3ef17e091e2eb',1,'CameraDeviceCAPI.h']]],
  ['royale_5fexposure_5fmode',['royale_exposure_mode',['../a00218.html#gaae4ebf6adb78fc488821d86d39bd207c',1,'ExposureModeCAPI.h']]],
  ['royale_5fextended_5fdata_5fcallback',['ROYALE_EXTENDED_DATA_CALLBACK',['../a00218.html#gabaec2d07df6dd9cea6709580be97d3b4',1,'ExtendedDataCAPI.h']]],
  ['royale_5fprocessing_5fflag',['royale_processing_flag',['../a00218.html#ga5775e778665b07181d44f6c905106271',1,'ProcessingParametersCAPI.h']]],
  ['royale_5fstream_5fid',['royale_stream_id',['../a00218.html#gafa71a01dfb94643e1f06b44b675bad79',1,'DataStructuresCAPI.h']]],
  ['royale_5ftrigger_5fmode',['royale_trigger_mode',['../a00218.html#ga3ad7806578ae4e530ae110f8ae60ba77',1,'TriggerModeCAPI.h']]],
  ['royale_5fvariant',['royale_variant',['../a00218.html#ga51d98667e33f8f3c78559ed60d31da72',1,'VariantCAPI.h']]],
  ['royale_5fvariant_5ftype',['royale_variant_type',['../a00218.html#ga8823a3fba64e30ddcc81d48e03a9b34f',1,'VariantCAPI.h']]]
];
