var searchData=
[
  ['severity',['Severity',['../a00023.html#a8eb79c79877bbf4601a7dc00f0cbfae4',1,'RoyaleDotNet::Event']]]
];
