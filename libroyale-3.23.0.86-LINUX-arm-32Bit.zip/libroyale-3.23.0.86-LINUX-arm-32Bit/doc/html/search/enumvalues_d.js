var searchData=
[
  ['slave',['SLAVE',['../a00209.html#a789748ed808cd6ff9d366c4ad060e45fa79e19bc2ac33d6c81272024561992f37',1,'royale::SLAVE()'],['../a00212.html#a3a6ddffbca905ff66a24060b3858d50eafe25c0ad752c03ce2361025c235b63e1',1,'RoyaleDotNet.Slave()']]],
  ['smoothingalpha_5ffloat',['SmoothingAlpha_Float',['../a00212.html#ab3fdff3ffcdd389ecf09923b128459c8a20b41f2ca104801595abb74fc90704bc',1,'RoyaleDotNet.SmoothingAlpha_Float()'],['../a00209.html#a7e10115488b46d46ac7703679b4e02c8a20b41f2ca104801595abb74fc90704bc',1,'royale::SmoothingAlpha_Float()']]],
  ['smoothingfiltertype_5fint',['SmoothingFilterType_Int',['../a00212.html#ab3fdff3ffcdd389ecf09923b128459c8aef0aef0f38dd687e7f0bb7c0ffb73044',1,'RoyaleDotNet.SmoothingFilterType_Int()'],['../a00209.html#a7e10115488b46d46ac7703679b4e02c8aef0aef0f38dd687e7f0bb7c0ffb73044',1,'royale::SmoothingFilterType_Int()']]],
  ['spectre_5fnot_5finitialized',['SPECTRE_NOT_INITIALIZED',['../a00218.html#ggaabcc5ca64cfb3f257f7ab6444dd33125afea178d75a47a7a68916e8ee543c537a',1,'SPECTRE_NOT_INITIALIZED():&#160;StatusCAPI.h'],['../a00212.html#a7c470186ff8f9b10c7383e4fde017288af5b11523579e950a919ce57067b26030',1,'RoyaleDotNet.SPECTRE_NOT_INITIALIZED()'],['../a00209.html#a895d6f2339238d7f35b996906bd7d054af5b11523579e950a919ce57067b26030',1,'royale::SPECTRE_NOT_INITIALIZED()']]],
  ['success',['SUCCESS',['../a00212.html#a7c470186ff8f9b10c7383e4fde017288ad0749aaba8b833466dfcbb0428e4f89c',1,'RoyaleDotNet.SUCCESS()'],['../a00209.html#a895d6f2339238d7f35b996906bd7d054ad0749aaba8b833466dfcbb0428e4f89c',1,'royale::SUCCESS()']]]
];
