var searchData=
[
  ['depthdata',['DepthData',['../a00025.html#ade39bcb39efb8001302a1df3b3a3eea5',1,'RoyaleDotNet::ExtendedData']]],
  ['description',['Description',['../a00023.html#ae0b60ef15930fa1c475aa4658637b186',1,'RoyaleDotNet::Event']]],
  ['distortionradial',['DistortionRadial',['../a00065.html#a35d436f1ef0f7267d13c2900c40c7627',1,'RoyaleDotNet::LensParameters']]],
  ['distortiontangential',['DistortionTangential',['../a00065.html#aff1301637a90d700466b1d2548000c0b',1,'RoyaleDotNet::LensParameters']]]
];
