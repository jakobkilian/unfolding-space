var searchData=
[
  ['phase_5fangles',['phase_angles',['../a00094.html#ac8fc4423e3350cc85a83b58bbc297349',1,'royale_raw_data']]],
  ['phaseangles',['phaseAngles',['../a00071.html#aa5e1a851bc7393bda964314c5decd3ee',1,'RoyaleDotNet.RawData.phaseAngles()'],['../a00072.html#aa04748cee652443bd7bd90f18b7711c5',1,'royale::RawData::phaseAngles()']]],
  ['points',['points',['../a00078.html#a834b3b139a17351ce4284fe6c581babb',1,'royale_depth_data::points()'],['../a00083.html#a66a3f4446ec5ef28b64028e54f7bb4f3',1,'royale_intermediate_data::points()'],['../a00015.html#a3380e902953023f1e788d57601226940',1,'RoyaleDotNet.DepthData.points()'],['../a00046.html#aededf048893714d928f610bb1592981b',1,'RoyaleDotNet.IntermediateData.points()'],['../a00016.html#ad694feb7746bb2b4a7aa0b804045176d',1,'royale::DepthData::points()'],['../a00045.html#aacf5f8c49c63d1ffff4b191a06b0d6c7',1,'royale::IntermediateData::points()']]],
  ['principalpoint',['principalPoint',['../a00088.html#a3bcddd0e94650054dd4cc86401266745',1,'royale_lens_parameters::principalPoint()'],['../a00066.html#a1af95893c2d205c4410c54bf2ed3267b',1,'royale::LensParameters::principalPoint()']]]
];
