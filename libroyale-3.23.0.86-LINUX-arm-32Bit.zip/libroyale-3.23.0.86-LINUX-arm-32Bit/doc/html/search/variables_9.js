var searchData=
[
  ['m_5fptr',['m_ptr',['../a00087.html#a06feed0793c7963a1d20f1c48855d073',1,'royale::iterator::royale_iterator_skeleton']]],
  ['manual',['MANUAL',['../a00145.html#a9745694aee3482607baa42f6db18919e',1,'ExposureMode.hpp']]],
  ['modulation_5ffrequencies',['modulation_frequencies',['../a00083.html#a38f2b3c1c458228ce488a3f7614f8045',1,'royale_intermediate_data::modulation_frequencies()'],['../a00094.html#a3e3b1101addefea04c9084ef373bab1c',1,'royale_raw_data::modulation_frequencies()']]],
  ['modulationfrequencies',['modulationFrequencies',['../a00046.html#af366bc4e0a4d7997ccb28cec24fec370',1,'RoyaleDotNet.IntermediateData.modulationFrequencies()'],['../a00071.html#acba220ba56bce8f8de99a446c2b175d8',1,'RoyaleDotNet.RawData.modulationFrequencies()'],['../a00045.html#a76826b41e0d2039111f88ad79b76ee39',1,'royale::IntermediateData::modulationFrequencies()'],['../a00072.html#a09683c0163e1120055800a1974e55f52',1,'royale::RawData::modulationFrequencies()']]]
];
