var searchData=
[
  ['rawdata',['RawData',['../a00025.html#a36e52e67dda336e6e28a60bd9ca2a850',1,'RoyaleDotNet::ExtendedData']]]
];
