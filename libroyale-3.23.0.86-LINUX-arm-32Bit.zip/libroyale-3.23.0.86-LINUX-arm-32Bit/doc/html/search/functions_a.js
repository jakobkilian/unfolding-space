var searchData=
[
  ['max_5fsize',['max_size',['../a00010.html#a83eb98ed08a7881fc13df7bc3cb0590b',1,'royale::basicString::max_size()'],['../a00110.html#a85c52893ab4a020bbf379cbe8bf3e8a5',1,'royale::Vector::max_size()']]],
  ['modulationsequence',['ModulationSequence',['../a00067.html#a8b9f3e4f21d385b23e097966957c4d83',1,'RoyaleDotNet::ModulationSequence']]]
];
