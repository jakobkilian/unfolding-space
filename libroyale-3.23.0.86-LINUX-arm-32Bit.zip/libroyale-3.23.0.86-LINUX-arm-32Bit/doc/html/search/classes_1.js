var searchData=
[
  ['basicstring',['basicString',['../a00010.html',1,'royale']]],
  ['bidirection_5fiterator_5ftag',['bidirection_iterator_tag',['../a00011.html',1,'royale::iterator']]]
];
