var searchData=
[
  ['modulationsequence',['ModulationSequence',['../a00067.html',1,'RoyaleDotNet']]]
];
