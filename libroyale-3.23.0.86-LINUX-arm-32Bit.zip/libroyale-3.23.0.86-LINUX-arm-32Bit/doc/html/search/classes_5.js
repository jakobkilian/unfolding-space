var searchData=
[
  ['forward_5fiterator_5ftag',['forward_iterator_tag',['../a00026.html',1,'royale::iterator']]]
];
