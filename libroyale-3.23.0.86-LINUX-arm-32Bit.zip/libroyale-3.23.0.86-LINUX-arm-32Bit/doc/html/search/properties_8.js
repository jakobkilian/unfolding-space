var searchData=
[
  ['modulationfrequency',['ModulationFrequency',['../a00067.html#ad6f1d64025efcdb844c80a47ccac9f4c',1,'RoyaleDotNet::ModulationSequence']]]
];
