var searchData=
[
  ['bool',['Bool',['../a00109.html#af9f10189cc9349f098c8ef5eb44d6272ac26f15e86e3de4c398a8273272aba034',1,'RoyaleDotNet.Variant.Bool()'],['../a00209.html#af729d5b431bf0b5a41c66513d30838d8ac26f15e86e3de4c398a8273272aba034',1,'royale::Bool()']]]
];
